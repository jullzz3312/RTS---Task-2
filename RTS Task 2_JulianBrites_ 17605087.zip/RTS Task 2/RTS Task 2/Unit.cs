﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS_Task_2
{
    abstract class Unit
    {
        private int xPos;
        private int yPos;
        private int health;
        private int speed;
        private bool attack;
        private int attackRange;
        private string faction;
        private string symbol;
        private int isAttacking;
        protected string name;


        #region Constructor

        public Unit(int xPos, int yPos, int health, int speed, bool attack, int attackRange, string faction, string symbol, int isAttacking, string name)
        {
            this.xPos = xPos;
            this.yPos = yPos;
            this.health = health;
            this.speed = speed;
            this.attack = attack;
            this.attackRange = attackRange;
            this.faction = faction;
            this.symbol = symbol;
            this.isAttacking = isAttacking;
            this.name = name;

        }

        #endregion

        ~Unit()
        {

        }

        #region Accessors
        public int XPos
        {
            get { return xPos; }
            set { xPos = value; }
        }

        public int YPos
        {
            get { return yPos; }
            set { yPos = value; }
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public bool Attack
        {
            get { return attack; }
            set { attack = value; }
        }

        public int AttackRange
        {
            get { return attackRange; }
            set { attackRange = value; }
        }

        public string Faction
        {
            get { return faction; }
            set { faction = value; }
        }

        public string Symbol
        {
            get { return symbol; }
            set { symbol = value; }
        }

        public int IsAttacking
        {
            get { return isAttacking; }
            set { isAttacking = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        #endregion




        public abstract void movePosition(int xPos, int yPos);
        public abstract void combat(Unit enemy);
        public abstract bool isWithinAttackRange(Unit enemy);                     // to determine whether an enemy is in attack range.
        public abstract Unit closestUnit(List<Unit> list);
        public abstract bool isAlive();
        public abstract string toString();
        public abstract void save();
    }
}