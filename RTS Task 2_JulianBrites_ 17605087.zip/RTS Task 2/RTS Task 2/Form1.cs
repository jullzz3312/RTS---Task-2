﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RTS_Task_2
{
    public partial class Form1 : Form
    {
            Map m = new Map();

            public Form1()
            {
                InitializeComponent();
            }

            private void Form1_Load(object sender, EventArgs e)
            {
                Globals.m.initialiseMap();
            }

            private void btnStart_Click(object sender, EventArgs e)
            {
                timer1.Start();
                Globals.m.warzone();
                txtmap.Text += Globals.m.redraw();
            }

            private void btnPause_Click(object sender, EventArgs e)
            {
                timer1.Stop();
            }

            #region Timer

            public void timer()
            {
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        if (Globals.m.map[i, j] != " .")
                        {
                            Globals.GE.rules();
                        }
                    }
                }
            }

            int count;
            private void timer1_Tick(object sender, EventArgs e)
            {
                timer();
                lblTime.Text = Convert.ToString(count++);

            }
            #endregion

            private void btnSave_Click(object sender, EventArgs e)
            {
                int XPos = int.Parse(ToString());
                int YPos = int.Parse(ToString());
                int Health = int.Parse(ToString());
                int Speed = int.Parse(ToString());
                bool Attack = bool.Parse(ToString());
                int AttackRange = int.Parse(ToString());
                string Faction = "";
                string Symbol = "";
                int IsAttacking = int.Parse(ToString());

                MeleeUnit m = new MeleeUnit(XPos, YPos, Health, Speed, Attack, AttackRange, Faction, Symbol, IsAttacking, Name);
                m.save();

                RangedUnit r = new RangedUnit(XPos, YPos, Health, Speed, Attack, AttackRange, Faction, Symbol, IsAttacking, Name);
                r.save();


                int PosX = int.Parse(ToString());
                int PosY = int.Parse(ToString());
                int hP = int.Parse(ToString());

                FactoryBuilding fb = new FactoryBuilding(PosX, PosY, hP, Faction, Symbol);
                fb.save();

                ResourceBuilding rb = new ResourceBuilding(PosX, PosY, hP, Faction, Symbol);
                rb.save();


                MessageBox.Show("Success!");
                this.Close();
            }

            private void btnRead_Click(object sender, EventArgs e)
            {
                lblShow.Text = "";
                m.read();
                for (int i = 0; i < m.mapUnitList.Count; i++)
                {
                    for (int j = 0; j < m.mapBuildingList1.Count; j++)
                    {
                        lblShow.Text += m.mapUnitList[i].toString();
                        lblShow.Text += m.mapBuildingList1[j].toString();
                    }
                }
            }
        }

        static class Globals
        {
            public static Map m = new Map();
            public static GameEngine GE = new GameEngine();

        }
    }
}
