﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace RTS_Task_2
{
    class Map
    {
        public string[,] map = new string[20, 20];
        public MeleeUnit[] closeCombat = new MeleeUnit[400];
        public RangedUnit[] rangedCombat = new RangedUnit[400];
        public List<MeleeUnit> mapUnitList = new List<MeleeUnit>();
        public List<FactoryBuilding> mapBuildingList1 = new List<FactoryBuilding>();

        // Accessors

        public List<MeleeUnit> MapUnitList
        {
            get { return mapUnitList; }
        }

        public List<FactoryBuilding> MapBuildingList1
        {
            get { return mapBuildingList1; }
        }


        public void initialiseMap()
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    map[i, j] = " .";
                }
            }
        }

        public string redraw()
        {
            string output = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    output += map[i, j];
                }
                output += Environment.NewLine;
            }
            return output;
        }

        public void warzone()
        {
            int skip = 0;
            int skip2 = 0;

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    Random rnd = new Random();
                    int xPos = rnd.Next(0, 20);
                    int yPos = rnd.Next(0, 20);
                    int unitChoice = rnd.Next(0, 3);
                    int teamChoice = rnd.Next(0, 3);



                    if ((unitChoice) % 2 == 0)
                    {
                        if ((teamChoice) % 2 == 0)
                        {
                            closeCombat[skip] = new MeleeUnit(xPos, yPos, 100, 0, true, 1, "Red", "M", 1, "Soldier");
                            map[xPos, yPos] = "M ";
                            skip++;
                        }
                        else
                        {
                            closeCombat[skip2] = new MeleeUnit(xPos, yPos, 100, 0, false, 1, "Green", "m", 0, "Knight");
                            map[xPos, yPos] = "m ";
                            skip2++;
                        }
                    }

                    {
                        if ((teamChoice) % 2 == 0)
                        {
                            rangedCombat[skip] = new RangedUnit(xPos, yPos, 100, 0, true, 5, "Red", "R", 1, "Gunner");
                            map[xPos, yPos] = "R ";
                            skip++;
                        }

                        {
                            rangedCombat[skip2] = new RangedUnit(xPos, yPos, 100, 0, false, 5, "Green", "r", 0, "Archer");
                            map[xPos, yPos] = "r ";
                            skip2++;

                        }
                    }
                }
            }
        }

        public void moveUnit(int xPos, int yPos, int XPos, int YPos)
        {
            string temp = "";
            temp = map[xPos, yPos];
            map[xPos, yPos] = " .";
            map[XPos, YPos] = temp;
        }

        public void updatePosition(int xPos, int yPos, int XPos, int YPos)
        {
            redraw();
            warzone();

        }

        public void read()
        {
            FileStream inFile = null;
            StreamReader reader = null;
            string output;
            int XPos;
            int YPos;
            int Health;
            int Speed;
            bool Attack;
            int AttackRange;
            string Faction;
            string Symbol;
            int IsAttacking;
            string Name;
            int PosX;
            int PosY;
            int HP;


            try
            {
                inFile = new FileStream(@"Files\MapObjects.txt", FileMode.Open, FileAccess.Read);
                reader = new StreamReader(inFile);
                output = reader.ReadLine();      // priming read
                while (output != null)
                {
                    XPos = int.Parse(output);
                    YPos = int.Parse(output);
                    Health = int.Parse(output);
                    Speed = int.Parse(output);
                    Attack = bool.Parse(output);
                    AttackRange = int.Parse(output);
                    IsAttacking = int.Parse(output);
                    PosX = int.Parse(output);
                    PosY = int.Parse(output);
                    HP = int.Parse(output);
                    Faction = reader.ReadLine();
                    Symbol = reader.ReadLine();
                    Name = reader.ReadLine();
                    MeleeUnit m = new MeleeUnit(XPos, YPos, Health, Speed, Attack, AttackRange, Faction, Symbol, IsAttacking, Name);
                    MapUnitList.Add(m);
                    FactoryBuilding b = new FactoryBuilding(PosX, PosY, HP, Faction, Symbol);
                    MapBuildingList1.Add(b);

                    output = reader.ReadLine();      // secondary read
                }
                reader.Close();
                inFile.Close();
            }
            catch (Exception fe)
            {
                Debug.WriteLine(fe.Message);
            }
            finally
            {
                if (inFile != null)
                {
                    reader.Close();
                    inFile.Close();
                }
            }
        }
    }
}
  