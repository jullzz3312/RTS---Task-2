﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS_Task_2
{
    abstract class Building
    {
        protected int posX;
        protected int posY;
        protected int hP;
        protected string faction;
        protected string symbol;


        #region Constructors


        public Building(int posX, int posY, int hP, string faction, string symbol)
        {
            this.posX = posX;
            this.posY = posY;
            this.hP = hP;
            this.faction = faction;
            this.symbol = symbol;

        }
        #endregion

        ~Building()
        {

        }

        #region Accessors
        public int POSX
        {
            get { return posX; }
            set { posX = value; }
        }

        public int POSY
        {
            get { return posY; }
            set { posY = value; }
        }

        public int HP
        {
            get { return hP; }
            set { hP = value; }
        }

        public string Faction
        {
            get { return faction; }
            set { faction = value; }
        }

        public string Symbol
        {
            get { return symbol; }
            set { symbol = value; }
        }
        #endregion



        public abstract bool isAlive();
        public abstract string toString();
        public abstract void save();

    }
}

