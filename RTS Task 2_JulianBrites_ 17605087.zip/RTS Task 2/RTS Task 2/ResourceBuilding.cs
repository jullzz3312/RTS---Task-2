﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace RTS_Task_2
{
    class ResourceBuilding : Building
    {
        private string[] resourceType = new string[4] { "Bronze", "Silver", "Gold", "Platinum" };
        private int resourcePerSecond = 5;
        private int resourceRemaining = 1000;
        private int totalResources;

        public ResourceBuilding(int posX, int posY, int hP, string faction, string symbol)
            : base(posX, posY, hP, faction, symbol)
        {

        }

        public void resourceCollection()
        {

            if (resourceRemaining >= 0)
                resourceRemaining -= resourcePerSecond;


        }

        public void resourceRemoval(int resourcePerSecond, int resourcesRemaining)
        {
            int maxResource = 5000;
            resourcesRemaining = maxResource - totalResources;

        }

        public override bool isAlive()
        {
            return (HP >= 0);
        }


        public override string toString()
        {
            string output;

            output = "X Co-ordinate:" + POSX + "\n";
            output = "Y Co-ordinate:" + POSY + "\n";
            output += "Health: " + HP + "\n";
            output += "Faction:" + Faction + "\n";
            output += "Symbol:" + Symbol + "\n";

            return output;
        }



        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {

                // open the file
                outFile = new FileStream("Files\\MapObjects.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);

                // write to the file
                writer.WriteLine(POSX);
                writer.WriteLine(POSY);
                writer.WriteLine(HP);
                writer.WriteLine(Faction);
                writer.WriteLine(Symbol);

                // close the file
                writer.Close();
                outFile.Close();
            }
            catch (Exception fe)
            {
                Debug.WriteLine(fe.Message);
            }
            finally
            {
                if (outFile != null)
                {
                    outFile.Close();
                    writer.Close();
                }
            }
        }
    }
}


